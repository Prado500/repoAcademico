package dal.example.POCEmpleado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PocEmpleadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PocEmpleadoApplication.class, args);
	}

}
